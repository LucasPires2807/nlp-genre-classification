---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:9980
- loss:CosineSimilarityLoss
base_model: sentence-transformers/all-MiniLM-L6-v2
widget:
- source_sentence: The Narrator tells us how the radio influenced his childhood in
    the days before TV. In the New York City of the late 1930s to the New Year's Eve
    1944, this coming-of-age tale mixes the narrator's experiences with contemporary
    anecdotes and urban legends of the radio stars.
  sentences:
  - The Narrator tells us how the radio influenced his childhood in the days before
    TV. In the New York City of the late 1930s to the New Year's Eve 1944, this coming-of-age
    tale mixes the narrator's experiences with contemporary anecdotes and urban legends
    of the radio stars.
  - While gathering evidence to support closing a tropical U.S. Air Force base, a
    congressional aide warms to its generous captain.
  - Somewhere in the Balkans, 1995. A team of aid workers must solve an apparently
    simple problem in an almost completely pacified territory that has been devastated
    by a cruel war, but some of the local inhabitants, the retreating combatants,
    the UN forces, many cows and an absurd bureaucracy will not cease to put obstacles
    in their way.
- source_sentence: El Topo decides to confront warrior Masters on a trans-formative
    desert journey he begins with his 6 year old son, who must bury his childhood
    totems to become a man.
  sentences:
  - While watching two children on Halloween night, a babysitter finds an old VHS
    tape in the kids' trick or treat bag. The tape features three tales of terror,
    all linked together by a murderous clown.
  - A hard-luck limo driver struggling to go straight and pay off a debt to his bookie
    takes on a job with a crazed passenger whose sought-after ledger implicates some
    seriously dangerous criminals.
  - El Topo decides to confront warrior Masters on a trans-formative desert journey
    he begins with his 6 year old son, who must bury his childhood totems to become
    a man.
- source_sentence: Henry II and his estranged queen battle over the choice of an heir.
  sentences:
  - Henry II and his estranged queen battle over the choice of an heir.
  - The Fantastic Four return to the big screen as a new and all powerful enemy threatens
    the Earth. The seemingly unstoppable 'Silver Surfer', but all is not what it seems
    and there are old and new enemies that pose a greater threat than the intrepid
    superheroes realize.
  - In Los Angeles, a gang of bank robbers who call themselves The Ex-Presidents commit
    their crimes while wearing masks of Reagan, Carter, Nixon and Johnson. Believing
    that the members of the gang could be surfers, the F.B.I. sends young agent Johnny
    Utah to the beach undercover to mix with the surfers and gather information.
- source_sentence: Miss Havisham, a wealthy spinster who wears an old wedding dress
    and lives in the dilapidated Satis House, asks Pip's Uncle Pumblechook to find
    a boy to play with her adopted daughter Estella. Pip begins to visit Miss Havisham
    and Estella, with whom he falls in love, then Pip—a humble orphan—suddenly becomes
    a gentleman with the help of an unknown benefactor.
  sentences:
  - Miss Havisham, a wealthy spinster who wears an old wedding dress and lives in
    the dilapidated Satis House, asks Pip's Uncle Pumblechook to find a boy to play
    with her adopted daughter Estella. Pip begins to visit Miss Havisham and Estella,
    with whom he falls in love, then Pip—a humble orphan—suddenly becomes a gentleman
    with the help of an unknown benefactor.
  - Sandra, a young woman forced to leave the south of France to flee a violent husband.
    Without attachment, she returned to Boulogne-sur-Mer, the city of her childhood
    which she left almost 15 years ago. She finds her mother there and a world she
    left behind. Without money, she is hired in a fish cannery where she befriends
    two workers. But one day, one of her colleagues tackles her insistently, she defends
    herself and kills him accidentally.
  - When a virus threatens to turn the now earth-dwelling friendly alien hybrids against
    humans, Captain Rose Corley must lead a team of elite mercenaries on a mission
    to the alien world in order to save what's left of humanity.
- source_sentence: A getaway driver for a bank robbery realizes he has been double
    crossed and races to find out who betrayed him.
  sentences:
  - An untraceable group of elite bank robbers is chased by a suicidal FBI agent who
    uncovers a deeper purpose behind the robbery-homicides.
  - When his new album fails to sell records, pop/rap superstar Conner4real goes into
    a major tailspin and watches his celebrity high life begin to collapse. He'll
    try anything to bounce back, anything except reuniting with his old rap group
    The Style Boyz.
  - A getaway driver for a bank robbery realizes he has been double crossed and races
    to find out who betrayed him.
pipeline_tag: sentence-similarity
library_name: sentence-transformers
---

# SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2). It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, text classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) <!-- at revision c9745ed1d9f207416be6d2e6f8de32d1f16199bf -->
- **Maximum Sequence Length:** 256 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 256, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 384, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
  (2): Normalize()
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'A getaway driver for a bank robbery realizes he has been double crossed and races to find out who betrayed him.',
    'A getaway driver for a bank robbery realizes he has been double crossed and races to find out who betrayed him.',
    "When his new album fails to sell records, pop/rap superstar Conner4real goes into a major tailspin and watches his celebrity high life begin to collapse. He'll try anything to bounce back, anything except reuniting with his old rap group The Style Boyz.",
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 9,980 training samples
* Columns: <code>sentence_0</code>, <code>sentence_1</code>, and <code>label</code>
* Approximate statistics based on the first 1000 samples:
  |         | sentence_0                                                                          | sentence_1                                                                          | label                                                         |
  |:--------|:------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|:--------------------------------------------------------------|
  | type    | string                                                                              | string                                                                              | float                                                         |
  | details | <ul><li>min: 16 tokens</li><li>mean: 58.51 tokens</li><li>max: 205 tokens</li></ul> | <ul><li>min: 16 tokens</li><li>mean: 58.51 tokens</li><li>max: 205 tokens</li></ul> | <ul><li>min: 1.0</li><li>mean: 1.0</li><li>max: 1.0</li></ul> |
* Samples:
  | sentence_0                                                                                                                                                                                                                                                                                                                                                                                                                                                            | sentence_1                                                                                                                                                                                                                                                                                                                                                                                                                                                            | label            |
  |:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------------|
  | <code>Heavyweight Champ George "Iceman" Chambers is sent to a Russian jail on trumped-up drug charges. In order to win his freedom he must fight against the jailhouse fighting champ Uri Boyka in a battle to the death. This time he is not fighting for a title, he is fighting for his life!</code>                                                                                                                                                               | <code>Heavyweight Champ George "Iceman" Chambers is sent to a Russian jail on trumped-up drug charges. In order to win his freedom he must fight against the jailhouse fighting champ Uri Boyka in a battle to the death. This time he is not fighting for a title, he is fighting for his life!</code>                                                                                                                                                               | <code>1.0</code> |
  | <code>Seventeen-year-old Shirley is a good student who works as a babysitter in order to make money for college. One night Michael, a father Shirley works for, confesses he's unhappy with married life. Shirley has a crush on Michael, and seizes this moment to kiss him. Michael is so happy he presents Shirley with a big tip, which gives her an idea. Shirley plans to make extra money by setting up her teenage friends with other unhappy fathers.</code> | <code>Seventeen-year-old Shirley is a good student who works as a babysitter in order to make money for college. One night Michael, a father Shirley works for, confesses he's unhappy with married life. Shirley has a crush on Michael, and seizes this moment to kiss him. Michael is so happy he presents Shirley with a big tip, which gives her an idea. Shirley plans to make extra money by setting up her teenage friends with other unhappy fathers.</code> | <code>1.0</code> |
  | <code>An anthology film presenting remakes of three episodes from the "Twilight Zone" TV series—"Kick the Can", "It's a Good Life" and "Nightmare at 20,000 Feet"—and one original story, "Time Out."</code>                                                                                                                                                                                                                                                          | <code>An anthology film presenting remakes of three episodes from the "Twilight Zone" TV series—"Kick the Can", "It's a Good Life" and "Nightmare at 20,000 Feet"—and one original story, "Time Out."</code>                                                                                                                                                                                                                                                          | <code>1.0</code> |
* Loss: [<code>CosineSimilarityLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#cosinesimilarityloss) with these parameters:
  ```json
  {
      "loss_fct": "torch.nn.modules.loss.MSELoss"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `per_device_train_batch_size`: 32
- `per_device_eval_batch_size`: 32
- `num_train_epochs`: 1
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: no
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 32
- `per_device_eval_batch_size`: 32
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `torch_empty_cache_steps`: None
- `learning_rate`: 5e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1
- `num_train_epochs`: 1
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.0
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: False
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: None
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `include_for_metrics`: []
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `use_liger_kernel`: False
- `eval_use_gather_object`: False
- `average_tokens_across_devices`: False
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin

</details>

### Framework Versions
- Python: 3.12.9
- Sentence Transformers: 4.1.0
- Transformers: 4.52.4
- PyTorch: 2.6.0+cpu
- Accelerate: 1.7.0
- Datasets: 3.6.0
- Tokenizers: 0.21.1

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->